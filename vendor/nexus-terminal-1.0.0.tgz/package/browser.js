import { n as e, r as t, t as n } from "./log-plugin-api-UW-KBQWD.js";
import { z as r } from "zod";
// src/http/http-problem-http-types.ts
var i = r.enum([
	"HTTP_INVALID_REQUEST",
	"HTTP_ORIGIN_DENIED",
	"HTTP_NOT_FOUND",
	"HTTP_PAYLOAD_TOO_LARGE",
	"HTTP_UNSUPPORTED_MEDIA_TYPE",
	"HTTP_INTERNAL_ERROR",
	"HTTP_ROUTE_CLOSED"
]), a = r.object({
	type: r.literal("about:blank"),
	status: r.number().int().min(400).max(599),
	code: r.string().regex(/^[A-Z][A-Z0-9_]*$/u)
}), o = class extends Error {
	status;
	code;
	name = "PluginHttpError";
	constructor(e, t) {
		super(t), this.status = e, this.code = t;
	}
};
export { i as HttpProblemCodeSchema, a as HttpProblemSchema, n as LogLevelSchema, e as LogParamsSchema, o as PluginHttpError, t as PluginLogInputSchema };
