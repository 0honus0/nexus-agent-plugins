import { z as e } from "zod";
// src/log/log-plugin-api.ts
var t = e.enum([
	"trace",
	"debug",
	"info",
	"warn",
	"error",
	"fatal"
]), n = e.record(e.string().min(1).max(80), e.union([
	e.string().max(2048),
	e.number().finite(),
	e.boolean()
])).refine((e) => Object.keys(e).length <= 32), r = e.strictObject({
	level: t,
	code: e.string().min(1).max(160).regex(/^[a-zA-Z0-9_.:-]+$/),
	params: n.optional(),
	correlationId: e.string().min(1).max(160).optional()
});
export { n, r, t };
