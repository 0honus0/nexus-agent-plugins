import { z as e } from "zod";
import { Fragment as t, Transition as n, computed as r, createBlock as i, createCommentVNode as a, createElementBlock as o, createElementVNode as s, createTextVNode as c, createVNode as l, defineComponent as u, inject as d, mergeModels as f, mergeProps as p, nextTick as m, normalizeClass as h, onScopeDispose as g, openBlock as _, ref as v, renderList as y, renderSlot as b, resolveDynamicComponent as x, shallowRef as S, toDisplayString as C, unref as w, useId as T, useModel as E, useSlots as D, vModelDynamic as O, vShow as k, watch as A, withCtx as j, withDirectives as M, withModifiers as N } from "vue";
import { animateMini as P } from "motion-v";
import { unrefElement as F, useEventListener as I, usePointerSwipe as ee, usePreferredReducedMotion as L, useResizeObserver as te, useStorage as R, useWindowSize as z } from "@vueuse/core";
import { CollapsibleContent as B, CollapsibleRoot as V, CollapsibleTrigger as H, ContextMenuContent as ne, ContextMenuItem as re, ContextMenuPortal as U, ContextMenuRoot as W, ContextMenuSeparator as ie, ContextMenuTrigger as ae, DialogClose as oe, DialogContent as se, DialogDescription as ce, DialogOverlay as le, DialogPortal as ue, DialogRoot as de, DialogTitle as fe, DropdownMenuContent as pe, DropdownMenuItem as me, DropdownMenuPortal as he, DropdownMenuRoot as ge, DropdownMenuSeparator as _e, DropdownMenuTrigger as ve, Primitive as ye, SelectContent as be, SelectIcon as xe, SelectItem as Se, SelectItemText as Ce, SelectPortal as we, SelectRoot as Te, SelectScrollDownButton as Ee, SelectScrollUpButton as De, SelectTrigger as Oe, SelectValue as ke, SelectViewport as Ae, SliderRange as je, SliderRoot as Me, SliderThumb as Ne, SliderTrack as Pe, SwitchRoot as Fe, SwitchThumb as Ie, TabsContent as Le, TabsList as Re, TabsRoot as ze, TabsTrigger as Be, ToastClose as Ve, ToastDescription as He, ToastProvider as Ue, ToastRoot as We, ToastViewport as Ge } from "reka-ui";
import { ChevronDown as G, ChevronUp as Ke, Circle as qe, CircleAlert as Je, CircleCheck as Ye, CircleX as Xe, Info as Ze, LoaderCircle as Qe, X as $e } from "@lucide/vue";
import et from "interactjs";
// src/ui/browser/components/UiButton.vue?vue&type=script&setup=true&lang.ts
var tt = [
	"data-appearance",
	"data-tone",
	"data-density",
	"type",
	"disabled",
	"aria-busy",
	"data-loading-animation",
	"data-loading-placement"
], nt = { class: "ui-button__content" }, rt = {
	key: 0,
	class: "ui-button__leading"
}, it = { class: "ui-button__leading-content" }, at = {
	key: 0,
	class: "ui-button__loader",
	"aria-hidden": "true"
}, ot = {
	key: 0,
	class: "ui-button__loader",
	"aria-hidden": "true"
}, st = /*@__PURE__*/ u({
	__name: "UiButton",
	props: {
		appearance: { default: "soft" },
		tone: { default: "neutral" },
		density: { default: "default" },
		type: { default: "button" },
		disabled: {
			type: Boolean,
			default: !1
		},
		loading: {
			type: Boolean,
			default: !1
		},
		loadingAnimation: { default: "icon" },
		block: {
			type: Boolean,
			default: !1
		},
		iconOnly: {
			type: Boolean,
			default: !1
		}
	},
	setup(e) {
		let t = e, n = D();
		function r() {
			return t.loadingAnimation === "icon" && (t.iconOnly || !!n.leading);
		}
		function i() {
			return !t.iconOnly && n.leading ? "leading" : "content";
		}
		return (e, n) => (_(), o("button", {
			"data-ui": "button",
			"data-appearance": t.appearance,
			"data-tone": t.tone,
			"data-density": t.density,
			type: t.type,
			disabled: t.disabled || t.loading,
			"aria-busy": t.loading || void 0,
			"data-loading-animation": t.loading ? r() ? "icon" : "spinner" : void 0,
			"data-loading-placement": t.loading && !r() ? i() : void 0,
			class: h(["ui-button", {
				"ui-button--block": t.block,
				"ui-button--icon-only": t.iconOnly
			}])
		}, [s("span", nt, [
			e.$slots.leading ? (_(), o("span", rt, [s("span", it, [b(e.$slots, "leading", {}, void 0, !0)]), t.loading && !r() && i() === "leading" ? (_(), o("span", at, [...n[0] ||= [s("span", { class: "ui-button__spinner" }, null, -1)]])) : a("v-if", !0)])) : a("v-if", !0),
			b(e.$slots, "default", {}, void 0, !0),
			b(e.$slots, "trailing", {}, void 0, !0)
		]), t.loading && !r() && i() === "content" ? (_(), o("span", ot, [...n[1] ||= [s("span", { class: "ui-button__spinner" }, null, -1)]])) : a("v-if", !0)], 10, tt));
	}
}), K = (e, t) => {
	let n = e.__vccOpts || e;
	for (let [e, r] of t) n[e] = r;
	return n;
}, q = /*#__PURE__*/ K(st, [["__scopeId", "data-v-bcddf2a3"]]), ct = {
	class: "ui-field",
	"data-ui": "field"
}, lt = ["for"], ut = ["id"], dt = /*#__PURE__*/ K(/* @__PURE__ */ u({
	__name: "UiField",
	props: {
		label: {},
		hint: {},
		id: {}
	},
	setup(e) {
		let t = e, n = T();
		return (r, i) => (_(), o("div", ct, [
			s("label", { for: t.id ?? w(n) }, C(e.label), 9, lt),
			b(r.$slots, "default", {
				id: t.id ?? w(n),
				describedby: e.hint ? `${t.id ?? w(n)}-hint` : void 0
			}, void 0, !0),
			e.hint ? (_(), o("p", {
				key: 0,
				id: `${t.id ?? w(n)}-hint`
			}, C(e.hint), 9, ut)) : a("v-if", !0)
		]));
	}
}), [["__scopeId", "data-v-2f372308"]]), ft = [
	"data-density",
	"data-invalid",
	"data-disabled"
], pt = {
	key: 0,
	class: "ui-input__accessory"
}, mt = ["type", "disabled"], ht = {
	key: 1,
	class: "ui-input__accessory"
}, gt = /*#__PURE__*/ K(/* @__PURE__ */ u({
	inheritAttrs: !1,
	__name: "UiInput",
	props: /*@__PURE__*/ f({
		type: { default: "text" },
		disabled: { type: Boolean },
		density: { default: "default" },
		invalid: { type: Boolean }
	}, {
		modelValue: { default: "" },
		modelModifiers: {}
	}),
	emits: ["update:modelValue"],
	setup(e) {
		let t = E(e, "modelValue");
		return (n, r) => (_(), o("div", {
			class: "ui-input",
			"data-ui": "input",
			"data-density": e.density,
			"data-invalid": e.invalid || void 0,
			"data-disabled": e.disabled || void 0
		}, [
			n.$slots.leading ? (_(), o("span", pt, [b(n.$slots, "leading", {}, void 0, !0)])) : a("v-if", !0),
			M(s("input", p({
				...n.$attrs,
				...e.invalid ? { "aria-invalid": !0 } : {}
			}, {
				"onUpdate:modelValue": r[0] ||= (e) => t.value = e,
				type: e.type,
				disabled: e.disabled
			}), null, 16, mt), [[O, t.value]]),
			n.$slots.trailing ? (_(), o("span", ht, [b(n.$slots, "trailing", {}, void 0, !0)])) : a("v-if", !0)
		], 8, ft));
	}
}), [["__scopeId", "data-v-3554157c"]]), _t = Symbol("ui.motion"), J = /* @__PURE__ */ new WeakMap();
function vt() {
	let e = L(), t = d(_t, {
		enabled: r(() => e.value !== "reduce"),
		speed: r(() => 1)
	}), n = /* @__PURE__ */ new Map();
	function i(e, r, i, a = () => {}) {
		let o = Object.keys(r.at(-1) ?? {}).filter((e) => ![
			"offset",
			"easing",
			"composite"
		].includes(e)), s = J.get(e), c = s ? getComputedStyle(e) : void 0, l = new Map(s?.properties.map((e) => [e, c.getPropertyValue(e)]));
		if (s?.finish(), !t.enabled.value || !e.animate) return a(), () => {};
		let u = new Map(o.map((t) => [t, e.style.getPropertyValue(t)])), d = Object.fromEntries(o.map((e) => [e, r.map((t, n) => n === 0 && l.has(e) ? l.get(e) : t[e])])), f = P(e, d, {
			duration: i / 1e3,
			ease: [
				.25,
				.1,
				.25,
				1
			]
		});
		f.speed = t.speed.value;
		let p = !1;
		function m() {
			if (!p) {
				p = !0, n.delete(f), J.get(e)?.finish === m && J.delete(e), f.cancel();
				for (let [t, n] of u) n ? e.style.setProperty(t, n) : e.style.removeProperty(t);
				a();
			}
		}
		return J.set(e, {
			finish: m,
			properties: o
		}), n.set(f, m), f.finished.then(m, m), m;
	}
	return A(t.enabled, (e) => {
		if (!e) for (let e of [...n.values()]) e();
	}, { flush: "sync" }), A(t.speed, (e) => {
		for (let t of n.keys()) t.speed = e;
	}, { flush: "sync" }), g(() => {
		for (let e of [...n.values()]) e();
	}), { play: i };
}
// src/ui/browser/components/UiTransition.vue
var Y = /* @__PURE__ */ u({
	__name: "UiTransition",
	props: {
		preset: { default: "panel" },
		appear: {
			type: Boolean,
			default: !0
		}
	},
	setup(e) {
		let t = e, { play: r } = vt(), a = /* @__PURE__ */ new WeakMap();
		function o(e, n) {
			let i = e;
			if (i.inert = !1, a.has(i)) {
				let e = a.get(i);
				e === null ? i.removeAttribute("aria-hidden") : i.setAttribute("aria-hidden", e), a.delete(i);
			}
			r(i, [{
				opacity: 0,
				scale: t.preset === "fade" ? "1" : ".98"
			}, {
				opacity: 1,
				scale: "1"
			}], 200, n);
		}
		function s(e, n) {
			let i = e;
			i.inert = !0, a.has(i) || a.set(i, i.getAttribute("aria-hidden")), i.setAttribute("aria-hidden", "true"), r(i, [{
				opacity: 1,
				scale: "1"
			}, {
				opacity: 0,
				scale: t.preset === "fade" ? "1" : ".98"
			}], 140, n);
		}
		return (t, r) => (_(), i(n, {
			css: !1,
			appear: e.appear,
			onEnter: o,
			onLeave: s
		}, {
			default: j(() => [b(t.$slots, "default")]),
			_: 3
		}, 8, ["appear"]));
	}
}), X;
function yt() {
	X?.dismiss();
}
function Z(e) {
	let t = !0, n = { dismiss() {
		t = !1, e.value = !1;
	} };
	return A(e, (e) => {
		e ? (X !== n && X?.dismiss(), t = !0, X = n) : X === n && (X = void 0);
	}, {
		immediate: !0,
		flush: "sync"
	}), g(() => {
		X === n && (X = void 0);
	}), {
		interactOutside() {
			t = !1;
		},
		closeAutoFocus(e) {
			t || e.preventDefault();
		},
		select(e, t) {
			n.dismiss(), e?.focus({ preventScroll: !0 }), t();
		}
	};
}
// src/ui/browser/components/UiSelect.vue
var bt = /*#__PURE__*/ K(/* @__PURE__ */ u({
	inheritAttrs: !1,
	__name: "UiSelect",
	props: /*@__PURE__*/ f({
		options: {},
		placeholder: {},
		name: {},
		required: {
			type: Boolean,
			default: !1
		},
		disabled: {
			type: Boolean,
			default: !1
		},
		invalid: {
			type: Boolean,
			default: !1
		},
		block: {
			type: Boolean,
			default: !1
		},
		density: { default: "default" },
		contentAlign: { default: "center" }
	}, {
		modelValue: {},
		modelModifiers: {},
		open: {
			type: Boolean,
			default: !1
		},
		openModifiers: {}
	}),
	emits: ["update:modelValue", "update:open"],
	setup(e) {
		let n = E(e, "modelValue"), s = E(e, "open"), u = Z(s), d = e, f = r(() => d.options.find((e) => e.value === n.value)?.label ?? d.placeholder ?? "");
		return (e, r) => (_(), i(w(Te), {
			modelValue: n.value,
			"onUpdate:modelValue": r[0] ||= (e) => n.value = e,
			open: s.value,
			"onUpdate:open": r[1] ||= (e) => s.value = e,
			name: d.name,
			required: d.required,
			disabled: d.disabled || d.options.length === 0
		}, {
			default: j(() => [l(w(Oe), p(e.$attrs, {
				"data-ui": "select",
				"data-density": d.density,
				"aria-invalid": d.invalid || void 0,
				class: ["ui-select", { "ui-select--block": d.block }]
			}), {
				default: j(() => [l(w(ke), {
					class: "ui-select__value",
					placeholder: d.placeholder
				}, {
					default: j(() => [c(C(f.value), 1)]),
					_: 1
				}, 8, ["placeholder"]), l(w(xe), { class: "ui-select__icon" }, {
					default: j(() => [l(w(G), { size: 15 })]),
					_: 1
				})]),
				_: 1
			}, 16, [
				"data-density",
				"aria-invalid",
				"class"
			]), d.options.length ? (_(), i(w(we), { key: 0 }, {
				default: j(() => [l(Y, { preset: "fade" }, {
					default: j(() => [s.value ? (_(), i(w(be), {
						key: 0,
						"force-mount": "",
						"data-ui": "select-content",
						class: "ui-select-content",
						position: "popper",
						"body-lock": !1,
						"disable-outside-pointer-events": !1,
						onPointerDownOutside: w(u).interactOutside,
						onCloseAutoFocus: w(u).closeAutoFocus,
						align: d.contentAlign,
						"side-offset": 6,
						"collision-padding": 12
					}, {
						default: j(() => [
							l(w(De), { class: "ui-select-scroll" }, {
								default: j(() => [l(w(Ke), { size: 15 })]),
								_: 1
							}),
							l(w(Ae), { class: "ui-select-viewport" }, {
								default: j(() => [(_(!0), o(t, null, y(d.options, (e) => (_(), i(w(Se), {
									key: e.value,
									value: e.value,
									disabled: e.disabled,
									class: "ui-select-option"
								}, {
									default: j(() => [a(" 当前值由上方选择框展示；选中语义与键盘高亮由 Reka 保留。 "), l(w(Ce), { class: "ui-select-option__label" }, {
										default: j(() => [c(C(e.label), 1)]),
										_: 2
									}, 1024)]),
									_: 2
								}, 1032, ["value", "disabled"]))), 128))]),
								_: 1
							}),
							l(w(Ee), { class: "ui-select-scroll" }, {
								default: j(() => [l(w(G), { size: 15 })]),
								_: 1
							})
						]),
						_: 1
					}, 8, [
						"onPointerDownOutside",
						"onCloseAutoFocus",
						"align"
					])) : a("v-if", !0)]),
					_: 1
				})]),
				_: 1
			})) : a("v-if", !0)]),
			_: 1
		}, 8, [
			"modelValue",
			"open",
			"name",
			"required",
			"disabled"
		]));
	}
}), [["__scopeId", "data-v-81a0c408"]]), xt = ["data-tone", "data-expanded"], St = { class: "ui-toast__icon" }, Ct = { class: "ui-toast__content" }, wt = {
	key: 0,
	class: "ui-toast__footer"
}, Tt = ["aria-expanded"], Et = {
	key: 1,
	class: "ui-toast__navigation"
}, Dt = ["aria-label"], Ot = /* @__PURE__ */ u({
	inheritAttrs: !1,
	__name: "UiToastStack",
	props: {
		items: {},
		label: {},
		closeLabel: {},
		expandLabel: {},
		collapseLabel: {},
		positionLabel: {},
		duration: { default: 5e3 }
	},
	emits: ["dismiss"],
	setup(e, { emit: t }) {
		let n = e, u = t, d = v(), f = v(!1), g = v(), y = v(), b = v(!1), S = {
			info: Ze,
			success: Ye,
			warning: Je,
			error: Je
		}, T = r(() => n.items.findIndex((e) => e.id === d.value)), E = r(() => n.items[T.value]), D = r(() => n.items.length - T.value), { play: O } = vt(), k = !1, M, P = () => {}, F = !1, L = 0, R = 0, z = 0;
		function B() {
			!f.value && y.value && (b.value = y.value.scrollHeight > y.value.clientHeight + 1);
		}
		te(y, B), A([() => E.value?.message, f], () => m(B)), A(() => n.items.map((e) => e.id), (e, t = []) => {
			let n = e.at(-1);
			if (n !== void 0 && !t.includes(n)) d.value = n;
			else if (!e.includes(d.value)) {
				let n = t.indexOf(d.value);
				d.value = e[Math.max(0, Math.min(n - 1, e.length - 1))];
			}
		}, {
			immediate: !0,
			flush: "sync"
		}), A(d, async (e) => {
			P(), k = !1, f.value = !1, b.value = !1, await m(), B(), g.value && d.value === e && (P = O(g.value, [{
				opacity: 0,
				transform: "translateY(-6px)"
			}, {
				opacity: 1,
				transform: "translateY(0)"
			}], 160));
		});
		function V(e) {
			if (n.items.length < 2) return;
			let t = (T.value + e + n.items.length) % n.items.length, r = g.value?.contains(document.activeElement);
			d.value = n.items[t].id, r && m(() => g.value?.focus({ preventScroll: !0 }));
		}
		function H() {
			if (!E.value) return;
			let e = g.value?.contains(document.activeElement);
			u("dismiss", E.value.id), e && n.items.length && m(() => g.value?.focus({ preventScroll: !0 }));
		}
		function ne(e) {
			f.value = !f.value, e.currentTarget.focus({ preventScroll: !0 });
		}
		I("keydown", (e) => {
			e.key === "Escape" && E.value && (e.preventDefault(), e.stopPropagation(), H());
		}, { capture: !0 });
		function re(e) {
			(e.key === "ArrowUp" || e.key === "ArrowDown") && (e.preventDefault(), e.stopPropagation(), V(e.key === "ArrowUp" ? 1 : -1));
		}
		function U(e) {
			if (e.ctrlKey || (e.stopPropagation(), f.value && e.target.closest(".ui-toast__message")) || (e.preventDefault(), n.items.length < 2)) return;
			let t = performance.now();
			if (t < z || !Number.isFinite(e.deltaY)) return;
			(t - R > 200 || Math.sign(L) !== Math.sign(e.deltaY)) && (L = 0), R = t;
			let r = e.deltaY * (e.deltaMode === 1 ? 16 : e.deltaMode === 2 ? 200 : 1);
			L += r, Math.abs(L) < 32 || (V(L > 0 ? -1 : 1), L = 0, z = t + 260);
		}
		let W = ee(g, {
			threshold: 24,
			onSwipeStart(e) {
				P(), M = d.value, k = e.isPrimary && e.button === 0 && !e.target.closest("button, .ui-toast__message.is-expanded"), F = !1;
			},
			onSwipe() {
				if (!k || M !== d.value || !g.value) return;
				F = !0;
				let e = -W.distanceX.value;
				Math.abs(e) > Math.abs(W.distanceY.value) && (g.value.style.transform = `translateX(${e}px)`, g.value.style.opacity = String(Math.max(.3, 1 - Math.abs(e) / g.value.clientWidth)));
			},
			onSwipeEnd(e, t) {
				k && M === d.value && (k = !1, g.value && (g.value.style.removeProperty("transform"), g.value.style.removeProperty("opacity")), e.type !== "pointercancel" && (t === "left" || t === "right" ? Math.abs(W.distanceX.value) >= 56 && H() : (t === "up" || t === "down") && V(t === "up" ? -1 : 1)));
			}
		});
		return I(g, "click", (e) => {
			F && (e.preventDefault(), e.stopImmediatePropagation());
		}, { capture: !0 }), I(g, "pointercancel", () => {
			k = !1;
		}), (t, n) => (_(), i(w(Ue), {
			duration: f.value ? Infinity : e.duration,
			label: e.label,
			"disable-swipe": ""
		}, {
			default: j(() => [E.value ? (_(), i(w(We), {
				key: E.value.id,
				"as-child": "",
				open: !0,
				"onUpdate:open": n[0] ||= (e) => {
					e || H();
				}
			}, {
				default: j(() => [s("li", {
					ref_key: "card",
					ref: g,
					class: "ui-toast",
					"data-ui": "toast",
					"data-tone": E.value.tone,
					"data-expanded": f.value || void 0,
					onKeydown: re
				}, [
					s("div", St, [(_(), i(x(S[E.value.tone]), {
						size: 18,
						"aria-hidden": "true"
					}))]),
					s("div", Ct, [l(w(He), { "as-child": "" }, {
						default: j(() => [s("p", {
							ref_key: "message",
							ref: y,
							class: h(["ui-toast__message", { "is-expanded": f.value }])
						}, C(E.value.message), 3)]),
						_: 1
					}), b.value || f.value || e.items.length > 1 ? (_(), o("div", wt, [b.value || f.value ? (_(), o("button", {
						key: 0,
						class: "ui-toast__expand",
						type: "button",
						"aria-expanded": f.value,
						onClick: ne
					}, [c(C(f.value ? e.collapseLabel : e.expandLabel) + " ", 1), f.value ? (_(), i(w(Ke), {
						key: 0,
						size: 12,
						"aria-hidden": "true"
					})) : (_(), i(w(G), {
						key: 1,
						size: 12,
						"aria-hidden": "true"
					}))], 8, Tt)) : a("v-if", !0), e.items.length > 1 ? (_(), o("div", Et, [s("span", { "aria-label": e.positionLabel(D.value, e.items.length) }, [
						s("strong", null, C(D.value), 1),
						n[4] ||= s("span", { "aria-hidden": "true" }, " / ", -1),
						c(C(e.items.length), 1)
					], 8, Dt)])) : a("v-if", !0)])) : a("v-if", !0)]),
					l(w(Ve), {
						class: "ui-toast__close",
						"aria-label": e.closeLabel
					}, {
						default: j(() => [l(w($e), {
							size: 15,
							"aria-hidden": "true"
						})]),
						_: 1
					}, 8, ["aria-label"])
				], 40, xt)]),
				_: 1
			})) : a("v-if", !0), l(w(Ge), p(t.$attrs, {
				class: "ui-toast-stack",
				"data-ui": "toast-stack",
				"data-count": Math.min(e.items.length, 3),
				label: e.label,
				onWheel: U,
				onTouchmove: n[1] ||= N(() => {}, ["stop"]),
				onPointerdown: n[2] ||= N(() => {}, ["stop"]),
				onPointerup: n[3] ||= N(() => {}, ["stop"])
			}), null, 16, ["data-count", "label"])]),
			_: 1
		}, 8, ["duration", "label"]));
	}
}), kt = e.enum([
	"compact",
	"medium",
	"wide"
]), At = {
	compact: {
		minWidth: 0,
		columns: 4
	},
	medium: {
		minWidth: 700,
		columns: 8
	},
	wide: {
		minWidth: 1200,
		columns: 12
	}
};
function jt(e) {
	return e >= At.wide.minWidth ? "wide" : e >= At.medium.minWidth ? "medium" : "compact";
}
// src/ui/browser/ui-resize.ts
var Mt = {
	top: "[data-ui-resize-edges~=\"top\"]",
	right: "[data-ui-resize-edges~=\"right\"]",
	bottom: "[data-ui-resize-edges~=\"bottom\"]",
	left: "[data-ui-resize-edges~=\"left\"]"
}, Nt = e.object({
	x: e.number().finite(),
	y: e.number().finite(),
	width: e.number().positive().finite(),
	height: e.number().positive().finite()
}), Pt = e.partialRecord(kt, Nt);
function Ft(e, t, n, i) {
	let { width: a, height: o } = z({ includeScrollbar: !1 }), s = r(() => jt(a.value)), c = r(() => e.size !== "fullscreen" && !!(e.draggable || e.resizable)), l = S(), u = R(() => `nexus.ui.dialog.${e.persistenceKey ?? ""}`, {}, void 0, {
		deep: !1,
		writeDefaults: !1,
		serializer: {
			read: (e) => Pt.parse(JSON.parse(e)),
			write: JSON.stringify
		},
		onError: i
	});
	function d(e) {
		let t = Math.max(1, a.value - 32), n = Math.max(1, o.value - 32), r = Math.min(t, Math.max(Math.min(320, t), e.width)), i = Math.min(n, Math.max(Math.min(240, n), e.height));
		return {
			x: Math.max(16, Math.min(e.x, a.value - r - 16)),
			y: Math.max(16, Math.min(e.y, o.value - i - 16)),
			width: r,
			height: i
		};
	}
	function f() {
		e.persistenceKey && l.value && (u.value = {
			...u.value,
			[s.value]: { ...l.value }
		});
	}
	function p() {
		if (l.value) return d(l.value);
		let e = n.value?.getBoundingClientRect();
		if (e) return d({
			x: e.left,
			y: e.top,
			width: e.width,
			height: e.height
		});
	}
	function m(e, t, n = 0, r = 0) {
		let i = p();
		if (!i) return;
		let s = i.x + n, c = i.y + r;
		l.value = d({
			...i,
			x: s,
			y: c,
			width: Math.min(e, a.value - s - 16),
			height: Math.min(t, o.value - c - 16)
		});
	}
	function h(t, n) {
		if (!c.value || !e.resizable) return;
		let r = p();
		r && (m(r.width + t, r.height + n), f());
	}
	A([
		n,
		t,
		c,
		() => e.persistenceKey,
		() => e.size,
		() => e.draggable,
		() => e.resizable,
		s
	], ([t, n, r], i, a) => {
		let o;
		a(() => {
			o?.unset();
		}), l.value = void 0, t && n && r && (l.value = e.persistenceKey && u.value[s.value] || void 0, o = et(t).draggable({
			enabled: !!e.draggable,
			allowFrom: ".ui-dialog__header",
			ignoreFrom: "button, a, input, textarea, select, [contenteditable], [data-dialog-no-drag]",
			listeners: {
				move: (e) => {
					let t = p();
					t && (l.value = d({
						...t,
						x: t.x + e.dx,
						y: t.y + e.dy
					}));
				},
				end: f
			}
		}).resizable({
			enabled: !!e.resizable,
			edges: Mt,
			modifiers: [et.modifiers.restrictSize({ min: {
				width: 320,
				height: 240
			} })],
			listeners: {
				move: (e) => m(e.rect.width, e.rect.height, e.deltaRect.left, e.deltaRect.top),
				end: f
			}
		}));
	}, {
		immediate: !0,
		flush: "post"
	});
	let g = r(() => l.value && d(l.value));
	return {
		enabled: c,
		style: r(() => g.value ? {
			left: `${g.value.x}px`,
			top: `${g.value.y}px`,
			width: `${g.value.width}px`,
			height: `${g.value.height}px`,
			maxHeight: `${Math.max(1, o.value - 32)}px`,
			transform: "none"
		} : void 0),
		resizeBy: h
	};
}
// src/ui/browser/components/UiScrollArea.vue
var Q = /* @__PURE__ */ u({
	__name: "UiScrollArea",
	props: {
		asChild: {
			type: Boolean,
			default: !1
		},
		gutter: { default: "auto" },
		overflow: { default: "auto" },
		scrollbar: { default: "auto" }
	},
	setup(e) {
		let t = e;
		return (e, n) => (_(), i(w(ye), {
			"as-child": t.asChild,
			class: "ui-scroll-area",
			"data-scrollbar-gutter": t.gutter,
			"data-scroll-overflow": t.overflow,
			"data-scrollbar": t.scrollbar
		}, {
			default: j(() => [b(e.$slots, "default")]),
			_: 3
		}, 8, [
			"as-child",
			"data-scrollbar-gutter",
			"data-scroll-overflow",
			"data-scrollbar"
		]));
	}
}), It = ["aria-label"], Lt = {
	key: 0,
	class: "ui-resize-edges",
	"aria-hidden": "true"
}, Rt = ["data-ui-resize-edges"], zt = /*#__PURE__*/ K(/* @__PURE__ */ u({
	inheritAttrs: !1,
	__name: "UiResizeHandle",
	props: {
		label: {},
		edges: { type: Boolean }
	},
	emits: ["resize"],
	setup(e, { emit: n }) {
		let r = e, i = n;
		function c(e) {
			let t = {
				ArrowLeft: [-1, 0],
				ArrowRight: [1, 0],
				ArrowUp: [0, -1],
				ArrowDown: [0, 1]
			}[e.key];
			if (!t) return;
			e.preventDefault(), e.stopPropagation();
			let n = e.shiftKey ? 48 : 16;
			i("resize", t[0] * n, t[1] * n);
		}
		return (e, n) => (_(), o(t, null, [s("button", p(e.$attrs, {
			type: "button",
			"data-ui": "resize-handle",
			"data-ui-resize-edges": "bottom right",
			class: ["ui-resize-handle", { "has-edges": r.edges }],
			"aria-label": r.label,
			onKeydown: c
		}), null, 16, It), r.edges ? (_(), o("span", Lt, [(_(), o(t, null, y([
			"top",
			"right",
			"bottom",
			"left",
			"top left",
			"top right",
			"bottom left"
		], (e) => s("span", {
			key: e,
			"data-ui-resize-edges": e
		}, null, 8, Rt)), 64))])) : a("v-if", !0)], 64));
	}
}), [["__scopeId", "data-v-e6ff7434"]]), Bt = [
	"data-size",
	"data-geometry",
	"data-draggable"
], Vt = { class: "ui-dialog__surface" }, Ht = ["data-ui-selection"], Ut = { class: "ui-dialog__heading" }, Wt = { class: "ui-dialog__footer" }, Gt = /*#__PURE__*/ K(/* @__PURE__ */ u({
	inheritAttrs: !1,
	__name: "UiDialog",
	props: /*@__PURE__*/ f({
		modal: {
			type: Boolean,
			default: !0
		},
		title: {},
		description: {},
		closeLabel: {},
		size: { default: "md" },
		showClose: {
			type: Boolean,
			default: !0
		},
		closeDisabled: {
			type: Boolean,
			default: !1
		},
		closeOnEscape: {
			type: Boolean,
			default: !0
		},
		closeOnInteractOutside: {
			type: Boolean,
			default: !0
		},
		draggable: { type: Boolean },
		resizable: {
			type: Boolean,
			default: !0
		},
		resizeLabel: {},
		persistenceKey: {},
		gutter: { default: "symmetric" },
		scrollbar: {}
	}, {
		open: {
			type: Boolean,
			default: !1
		},
		openModifiers: {}
	}),
	emits: /*@__PURE__*/ f(["storageError"], ["update:open"]),
	setup(e, { emit: t }) {
		let n = E(e, "open");
		A(n, (e) => {
			e && yt();
		}, {
			immediate: !0,
			flush: "sync"
		});
		let r = e, o = t, u = S(), d = Ft(r, n, u, (e) => o("storageError", e));
		function f() {
			m(!1);
		}
		function m(e) {
			(e || !r.closeDisabled) && (n.value = e);
		}
		return (e, t) => (_(), i(w(de), {
			open: n.value,
			modal: r.modal,
			"onUpdate:open": m
		}, {
			default: j(() => [l(w(ue), null, {
				default: j(() => [l(Y, { preset: "fade" }, {
					default: j(() => [r.modal && n.value ? (_(), i(w(le), {
						key: 0,
						"force-mount": "",
						"data-ui": "dialog-overlay",
						class: "ui-dialog-overlay"
					})) : a("v-if", !0)]),
					_: 1
				}), l(Y, null, {
					default: j(() => [n.value ? (_(), i(w(se), {
						key: 0,
						"force-mount": "",
						"as-child": "",
						onEscapeKeyDown: t[0] ||= (e) => (r.closeDisabled || !r.closeOnEscape) && e.preventDefault(),
						onInteractOutside: t[1] ||= (e) => (r.closeDisabled || !r.closeOnInteractOutside) && e.preventDefault()
					}, {
						default: j(() => [s("div", p({
							ref_key: "element",
							ref: u
						}, {
							...e.$attrs,
							...r.description ? {} : { "aria-describedby": void 0 }
						}, {
							"data-ui": "dialog",
							"data-size": r.size,
							"data-geometry": w(d).enabled.value || void 0,
							"data-draggable": w(d).enabled.value && r.draggable || void 0,
							style: w(d).style.value,
							class: "ui-dialog"
						}), [s("div", Vt, [
							l(Q, {
								"as-child": "",
								gutter: r.gutter,
								overflow: "hidden"
							}, {
								default: j(() => [s("header", {
									class: "ui-dialog__header",
									"data-ui-selection": r.draggable ? "none" : void 0
								}, [s("div", Ut, [l(w(fe), { class: "ui-dialog__title" }, {
									default: j(() => [b(e.$slots, "title", { title: r.title }, () => [c(C(r.title), 1)], !0)]),
									_: 3
								}), r.description ? (_(), i(w(ce), {
									key: 0,
									class: "ui-dialog__description"
								}, {
									default: j(() => [c(C(r.description), 1)]),
									_: 1
								})) : a("v-if", !0)]), r.showClose ? (_(), i(w(oe), {
									key: 0,
									"as-child": ""
								}, {
									default: j(() => [l(q, {
										appearance: "ghost",
										"icon-only": "",
										disabled: r.closeDisabled,
										"aria-label": r.closeLabel
									}, {
										default: j(() => [l(w($e), { size: 18 })]),
										_: 1
									}, 8, ["disabled", "aria-label"])]),
									_: 1
								})) : a("v-if", !0)], 8, Ht)]),
								_: 3
							}, 8, ["gutter"]),
							b(e.$slots, "body", { close: f }, () => [e.$slots.default ? (_(), i(Q, {
								key: 0,
								gutter: r.gutter,
								scrollbar: r.scrollbar,
								class: "ui-dialog__body"
							}, {
								default: j(() => [b(e.$slots, "default", { close: f }, void 0, !0)]),
								_: 3
							}, 8, ["gutter", "scrollbar"])) : a("v-if", !0)], !0),
							e.$slots.footer ? (_(), i(Q, {
								key: 0,
								"as-child": "",
								gutter: r.gutter,
								overflow: "hidden"
							}, {
								default: j(() => [s("footer", Wt, [b(e.$slots, "footer", { close: f }, void 0, !0)])]),
								_: 3
							}, 8, ["gutter"])) : a("v-if", !0)
						]), w(d).enabled.value && r.resizable ? (_(), i(zt, {
							key: 0,
							edges: "",
							label: r.resizeLabel ?? r.title,
							onResize: w(d).resizeBy
						}, null, 8, ["label", "onResize"])) : a("v-if", !0)], 16, Bt)]),
						_: 3
					})) : a("v-if", !0)]),
					_: 3
				})]),
				_: 3
			})]),
			_: 3
		}, 8, ["open", "modal"]));
	}
}), [["__scopeId", "data-v-2756f69c"]]);
// src/ui/browser/ui-selection.ts
function $(e) {
	let t = e.ownerDocument.getSelection();
	return !!t && !t.isCollapsed && t.rangeCount > 0 && t.toString().length > 0 && t.getRangeAt(0).intersectsNode(e);
}
function Kt(e) {
	if (e.button !== 0 || !e.isPrimary || e.shiftKey) return;
	let t = e.currentTarget;
	$(t) && t.ownerDocument.getSelection()?.removeAllRanges();
}
function qt(e) {
	e.detail !== 0 && $(e.currentTarget) && (e.preventDefault(), e.stopImmediatePropagation());
}
var Jt = {
	beforeMount(e) {
		e.addEventListener("pointerdown", Kt, !0), e.addEventListener("click", qt, !0);
	},
	beforeUnmount(e) {
		e.removeEventListener("pointerdown", Kt, !0), e.removeEventListener("click", qt, !0);
	}
}, Yt = [
	"disabled",
	"aria-label",
	"aria-describedby"
], Xt = ["id"], Zt = /*#__PURE__*/ K(/* @__PURE__ */ u({
	__name: "UiActionCard",
	props: {
		label: {},
		disabled: { type: Boolean }
	},
	setup(e) {
		let t = T();
		return (n, r) => (_(), o("button", {
			type: "button",
			class: "ui-action-card",
			disabled: e.disabled,
			"aria-label": e.label,
			"aria-describedby": w(t)
		}, [s("span", {
			id: w(t),
			class: "ui-action-card__content"
		}, [b(n.$slots, "default", {}, void 0, !0)], 8, Xt)], 8, Yt));
	}
}), [["__scopeId", "data-v-5969b36d"]]), Qt = /* @__PURE__ */ u({
	__name: "UiContextMenu",
	props: /*@__PURE__*/ f({
		items: {},
		disabled: { type: Boolean }
	}, {
		open: {
			type: Boolean,
			default: !1
		},
		openModifiers: {}
	}),
	emits: /*@__PURE__*/ f(["select"], ["update:open"]),
	setup(e, { emit: n }) {
		let r = E(e, "open"), c = n, u = v(), d = Z(r), f = (e) => d.select(F(u), () => c("select", e));
		return (n, c) => (_(), o(t, null, [a(" 右键、键盘菜单键、触屏长按与焦点收尾均交给 Reka；组件只处理样式和选项。 "), l(w(W), {
			open: r.value,
			"onUpdate:open": c[1] ||= (e) => r.value = e,
			modal: !1
		}, {
			default: j(() => [l(w(ae), {
				ref_key: "trigger",
				ref: u,
				"as-child": "",
				disabled: e.disabled
			}, {
				default: j(() => [b(n.$slots, "default")]),
				_: 3
			}, 8, ["disabled"]), l(w(U), null, {
				default: j(() => [l(Y, null, {
					default: j(() => [r.value ? (_(), i(w(ne), {
						key: 0,
						"force-mount": "",
						"data-ui": "context-menu",
						class: "ui-menu",
						onInteractOutside: w(d).interactOutside,
						onPointerupCapture: c[0] ||= (e) => e.button !== 0 && e.preventDefault(),
						onCloseAutoFocus: w(d).closeAutoFocus,
						"side-offset": 8,
						"collision-padding": 12
					}, {
						default: j(() => [(_(!0), o(t, null, y(e.items, (e) => (_(), o(t, { key: e.id }, [e.separatorBefore ? (_(), i(w(ie), {
							key: 0,
							class: "ui-menu__separator"
						})) : a("v-if", !0), l(w(re), {
							class: "ui-menu__item",
							"data-tone": e.tone ?? "neutral",
							disabled: e.disabled,
							onSelect: (t) => f(e.id)
						}, {
							default: j(() => [e.icon ? (_(), i(x(e.icon), {
								key: 0,
								size: 16
							})) : a("v-if", !0), s("span", null, C(e.label), 1)]),
							_: 2
						}, 1032, [
							"data-tone",
							"disabled",
							"onSelect"
						])], 64))), 128))]),
						_: 1
					}, 8, ["onInteractOutside", "onCloseAutoFocus"])) : a("v-if", !0)]),
					_: 1
				})]),
				_: 1
			})]),
			_: 3
		}, 8, ["open"])], 2112));
	}
}), $t = /*#__PURE__*/ K(/* @__PURE__ */ u({
	__name: "UiSwitch",
	props: /*@__PURE__*/ f({
		disabled: { type: Boolean },
		name: {},
		required: { type: Boolean }
	}, {
		modelValue: {
			type: Boolean,
			default: !1
		},
		modelModifiers: {}
	}),
	emits: ["update:modelValue"],
	setup(e) {
		let t = E(e, "modelValue");
		return (n, r) => (_(), i(w(Fe), {
			modelValue: t.value,
			"onUpdate:modelValue": r[0] ||= (e) => t.value = e,
			class: "ui-switch",
			"data-ui": "switch",
			disabled: e.disabled,
			name: e.name,
			required: e.required
		}, {
			default: j(() => [l(w(Ie), { class: "ui-switch__thumb" })]),
			_: 1
		}, 8, [
			"modelValue",
			"disabled",
			"name",
			"required"
		]));
	}
}), [["__scopeId", "data-v-91553e58"]]), en = /*#__PURE__*/ K(/* @__PURE__ */ u({
	inheritAttrs: !1,
	__name: "UiSlider",
	props: {
		modelValue: {},
		min: { default: 0 },
		max: { default: 100 },
		step: { default: 1 },
		disabled: { type: Boolean },
		name: {}
	},
	emits: [
		"update:modelValue",
		"commit",
		"cancel"
	],
	setup(e, { emit: t }) {
		let n = t;
		return (t, r) => (_(), i(w(Me), {
			class: "ui-slider",
			"data-ui": "slider",
			"model-value": [e.modelValue],
			min: e.min,
			max: e.max,
			step: e.step,
			disabled: e.disabled,
			name: e.name,
			"onUpdate:modelValue": r[0] ||= (e) => e?.[0] !== void 0 && n("update:modelValue", e[0]),
			onValueCommit: r[1] ||= (e) => e[0] !== void 0 && n("commit", e[0]),
			onPointercancel: r[2] ||= (e) => n("cancel")
		}, {
			default: j(() => [l(w(Pe), { class: "ui-slider__track" }, {
				default: j(() => [l(w(je), { class: "ui-slider__range" })]),
				_: 1
			}), l(w(Ne), p(t.$attrs, { class: "ui-slider__thumb" }), null, 16)]),
			_: 1
		}, 8, [
			"model-value",
			"min",
			"max",
			"step",
			"disabled",
			"name"
		]));
	}
}), [["__scopeId", "data-v-589610c4"]]), tn = ["data-stable"], nn = /*#__PURE__*/ K(/* @__PURE__ */ u({
	__name: "UiTabs",
	props: /*@__PURE__*/ f({
		options: {},
		label: {},
		defaultValue: {},
		stableHeight: { type: Boolean }
	}, {
		modelValue: {},
		modelModifiers: {}
	}),
	emits: ["update:modelValue"],
	setup(e) {
		let n = E(e, "modelValue");
		return (r, u) => (_(), i(w(ze), {
			modelValue: n.value,
			"onUpdate:modelValue": u[0] ||= (e) => n.value = e,
			"default-value": e.defaultValue,
			class: "ui-tabs",
			"data-ui": "tabs"
		}, {
			default: j(() => [l(w(Re), {
				class: "ui-tabs__list",
				"aria-label": e.label
			}, {
				default: j(() => [(_(!0), o(t, null, y(e.options, (e) => (_(), i(w(Be), {
					key: e.value,
					value: e.value,
					disabled: e.disabled,
					class: "ui-tabs__trigger"
				}, {
					default: j(() => [e.icon ? (_(), i(x(e.icon), {
						key: 0,
						size: 16
					})) : a("v-if", !0), c(C(e.label), 1)]),
					_: 2
				}, 1032, ["value", "disabled"]))), 128))]),
				_: 1
			}, 8, ["aria-label"]), s("div", {
				class: "ui-tabs__panels",
				"data-stable": e.stableHeight || void 0
			}, [(_(!0), o(t, null, y(e.options, (t) => (_(), i(w(Le), {
				key: t.value,
				value: t.value,
				"force-mount": e.stableHeight,
				class: "ui-tabs__panel"
			}, {
				default: j(() => [b(r.$slots, t.value, {}, void 0, !0)]),
				_: 2
			}, 1032, ["value", "force-mount"]))), 128))], 8, tn)]),
			_: 3
		}, 8, ["modelValue", "default-value"]));
	}
}), [["__scopeId", "data-v-377c1fa0"]]), rn = ["data-tone"], an = {
	key: 0,
	class: "ui-badge__dot",
	"aria-hidden": "true"
}, on = /*#__PURE__*/ K(/* @__PURE__ */ u({
	__name: "UiBadge",
	props: {
		tone: { default: "neutral" },
		dot: {
			type: Boolean,
			default: !1
		}
	},
	setup(e) {
		return (t, n) => (_(), o("span", {
			class: "ui-badge",
			"data-ui": "badge",
			"data-tone": e.tone
		}, [e.dot ? (_(), o("span", an)) : a("v-if", !0), b(t.$slots, "default", {}, void 0, !0)], 8, rn));
	}
}), [["__scopeId", "data-v-94a33925"]]), sn = {
	class: "ui-empty-state",
	"data-ui": "empty-state"
}, cn = {
	key: 0,
	class: "ui-empty-state__icon",
	"aria-hidden": "true"
}, ln = { key: 1 }, un = {
	key: 2,
	class: "ui-empty-state__actions"
}, dn = /*#__PURE__*/ K(/* @__PURE__ */ u({
	__name: "UiEmptyState",
	props: {
		title: {},
		description: {},
		icon: {}
	},
	setup(e) {
		return (t, n) => (_(), o("div", sn, [
			e.icon || t.$slots.icon ? (_(), o("span", cn, [b(t.$slots, "icon", {}, () => [(_(), i(x(e.icon), { size: 26 }))], !0)])) : a("v-if", !0),
			s("h3", null, C(e.title), 1),
			e.description ? (_(), o("p", ln, C(e.description), 1)) : a("v-if", !0),
			t.$slots.default ? (_(), o("div", un, [b(t.$slots, "default", {}, void 0, !0)])) : a("v-if", !0)
		]));
	}
}), [["__scopeId", "data-v-f7ed903a"]]), fn = ["data-tone"], pn = ["disabled", "aria-label"], mn = {
	key: 0,
	class: "ui-card__icon"
}, hn = {
	class: "ui-card__body",
	"data-ui-selection": "text"
}, gn = ["title"], _n = ["title"], vn = {
	key: 1,
	class: "ui-card__tags"
}, yn = {
	key: 0,
	class: "ui-card__side"
}, bn = {
	key: 0,
	class: "ui-card__badge"
}, xn = {
	key: 1,
	class: "ui-card__actions"
}, Sn = {
	key: 1,
	class: "ui-card__footer"
}, Cn = /*#__PURE__*/ K(/* @__PURE__ */ u({
	__name: "UiCard",
	props: {
		title: {},
		actionLabel: {},
		description: {},
		icon: {},
		tone: { default: "primary" },
		disabled: { type: Boolean }
	},
	emits: ["select"],
	setup(e) {
		return (t, n) => (_(), o("article", {
			class: "ui-card",
			"data-ui": "card",
			"data-tone": e.tone
		}, [
			M((_(), o("button", {
				type: "button",
				class: "ui-card__main",
				disabled: e.disabled,
				"aria-label": e.actionLabel,
				onClick: n[0] ||= (e) => t.$emit("select")
			}, [e.icon || t.$slots.icon ? (_(), o("span", mn, [b(t.$slots, "icon", {}, () => [(_(), i(x(e.icon), { size: 23 }))], !0)])) : a("v-if", !0), s("span", hn, [
				s("strong", { title: e.title }, C(e.title), 9, gn),
				e.description ? (_(), o("span", {
					key: 0,
					class: "ui-card__description",
					title: e.description
				}, C(e.description), 9, _n)) : a("v-if", !0),
				t.$slots.tags ? (_(), o("span", vn, [b(t.$slots, "tags", {}, void 0, !0)])) : a("v-if", !0)
			])], 8, pn)), [[w(Jt)]]),
			t.$slots.aside || t.$slots.badge || t.$slots.actions ? (_(), o("div", yn, [b(t.$slots, "aside", {}, () => [t.$slots.badge ? (_(), o("div", bn, [b(t.$slots, "badge", {}, void 0, !0)])) : a("v-if", !0), t.$slots.actions ? (_(), o("div", xn, [b(t.$slots, "actions", {}, void 0, !0)])) : a("v-if", !0)], !0)])) : a("v-if", !0),
			t.$slots.footer ? (_(), o("div", Sn, [b(t.$slots, "footer", {}, void 0, !0)])) : a("v-if", !0)
		], 8, fn));
	}
}), [["__scopeId", "data-v-9bd8ff89"]]), wn = /* @__PURE__ */ u({
	__name: "UiDropdownMenu",
	props: /*@__PURE__*/ f({
		items: {},
		disabled: { type: Boolean },
		align: { default: "end" }
	}, {
		open: {
			type: Boolean,
			default: !1
		},
		openModifiers: {}
	}),
	emits: /*@__PURE__*/ f(["select"], ["update:open"]),
	setup(e, { emit: n }) {
		let r = n, c = E(e, "open"), u = v(), d = Z(c), f = (e) => d.select(F(u), () => r("select", e));
		return (n, r) => (_(), i(w(ge), {
			open: c.value,
			"onUpdate:open": r[0] ||= (e) => c.value = e,
			modal: !1
		}, {
			default: j(() => [l(w(ve), {
				ref_key: "trigger",
				ref: u,
				"as-child": "",
				disabled: e.disabled || !e.items.length
			}, {
				default: j(() => [b(n.$slots, "default")]),
				_: 3
			}, 8, ["disabled"]), l(w(he), null, {
				default: j(() => [l(Y, null, {
					default: j(() => [c.value ? (_(), i(w(pe), {
						key: 0,
						"force-mount": "",
						"data-ui": "dropdown-menu",
						class: "ui-menu",
						align: e.align,
						"side-offset": 5,
						"collision-padding": 12,
						onInteractOutside: w(d).interactOutside,
						onCloseAutoFocus: w(d).closeAutoFocus
					}, {
						default: j(() => [(_(!0), o(t, null, y(e.items, (e) => (_(), o(t, { key: e.id }, [e.separatorBefore ? (_(), i(w(_e), {
							key: 0,
							class: "ui-menu__separator"
						})) : a("v-if", !0), l(w(me), {
							class: "ui-menu__item",
							"data-tone": e.tone ?? "neutral",
							disabled: e.disabled,
							onSelect: (t) => f(e.id)
						}, {
							default: j(() => [e.icon ? (_(), i(x(e.icon), {
								key: 0,
								size: 16
							})) : a("v-if", !0), s("span", null, C(e.label), 1)]),
							_: 2
						}, 1032, [
							"data-tone",
							"disabled",
							"onSelect"
						])], 64))), 128))]),
						_: 1
					}, 8, [
						"align",
						"onInteractOutside",
						"onCloseAutoFocus"
					])) : a("v-if", !0)]),
					_: 1
				})]),
				_: 1
			})]),
			_: 3
		}, 8, ["open"]));
	}
}), Tn = {}, En = {
	class: "ui-list",
	"data-ui": "list"
};
function Dn(e, t) {
	return _(), o("ul", En, [b(e.$slots, "default", {}, void 0, !0)]);
}
var On = /*#__PURE__*/ K(Tn, [["render", Dn], ["__scopeId", "data-v-a19901d7"]]), kn = {
	class: "ui-list-item",
	"data-ui": "list-item"
}, An = {
	key: 0,
	class: "ui-list-item__icon"
}, jn = {
	class: "ui-list-item__body",
	"data-ui-selection": "text"
}, Mn = { class: "ui-list-item__heading" }, Nn = ["title"], Pn = ["title"], Fn = {
	key: 1,
	class: "ui-list-item__actions"
}, In = /*#__PURE__*/ K(/* @__PURE__ */ u({
	__name: "UiListItem",
	props: {
		title: {},
		description: {},
		icon: {}
	},
	setup(e) {
		return (t, n) => (_(), o("li", kn, [
			e.icon || t.$slots.icon ? (_(), o("span", An, [b(t.$slots, "icon", {}, () => [(_(), i(x(e.icon), { size: 20 }))], !0)])) : a("v-if", !0),
			s("div", jn, [s("div", Mn, [s("strong", { title: e.title }, C(e.title), 9, Nn), b(t.$slots, "badge", {}, void 0, !0)]), e.description || t.$slots.description ? (_(), o("div", {
				key: 0,
				class: "ui-list-item__description",
				title: e.description
			}, [b(t.$slots, "description", {}, () => [c(C(e.description), 1)], !0)], 8, Pn)) : a("v-if", !0)]),
			t.$slots.actions ? (_(), o("div", Fn, [b(t.$slots, "actions", {}, void 0, !0)])) : a("v-if", !0)
		]));
	}
}), [["__scopeId", "data-v-cf274d89"]]), Ln = {
	key: 0,
	class: "ui-section__header"
}, Rn = { class: "ui-section__heading" }, zn = { key: 0 }, Bn = { key: 1 }, Vn = {
	key: 0,
	class: "ui-section__actions"
}, Hn = ["id"], Un = /*#__PURE__*/ K(/* @__PURE__ */ u({
	__name: "UiSection",
	props: /*@__PURE__*/ f({
		title: {},
		description: {},
		icon: {},
		appearance: { default: "plain" },
		collapsible: {
			type: Boolean,
			default: !1
		}
	}, {
		open: {
			type: Boolean,
			default: !0
		},
		openModifiers: {}
	}),
	emits: ["update:open"],
	setup(e) {
		let t = E(e, "open"), n = T();
		return (r, u) => (_(), i(w(V), {
			as: "section",
			class: "ui-section",
			"data-ui": "section",
			"data-appearance": e.appearance,
			open: !e.collapsible || t.value,
			"onUpdate:open": u[0] ||= (e) => t.value = e
		}, {
			default: j(() => [
				e.title || e.description || r.$slots.actions || e.collapsible ? (_(), o("header", Ln, [s("div", Rn, [e.title ? (_(), o("h2", zn, [e.icon ? (_(), i(x(e.icon), {
					key: 0,
					size: 18,
					"aria-hidden": "true"
				})) : a("v-if", !0), c(C(e.title), 1)])) : a("v-if", !0), e.description ? (_(), o("p", Bn, C(e.description), 1)) : a("v-if", !0)]), r.$slots.actions || e.collapsible ? (_(), o("div", Vn, [b(r.$slots, "actions", {}, void 0, !0), e.collapsible ? (_(), i(w(H), {
					key: 0,
					"as-child": ""
				}, {
					default: j(() => [l(q, {
						appearance: "ghost",
						density: "compact",
						"icon-only": "",
						"aria-label": e.title,
						"aria-controls": w(n)
					}, {
						default: j(() => [l(w(G), {
							class: "ui-section__chevron",
							size: 16,
							"aria-hidden": "true"
						})]),
						_: 1
					}, 8, ["aria-label", "aria-controls"])]),
					_: 1
				})) : a("v-if", !0)])) : a("v-if", !0)])) : a("v-if", !0),
				a(" 保持表单与列表挂载；折叠仅隐藏内容，不重置输入或业务状态。 "),
				e.collapsible ? (_(), i(w(B), {
					key: 1,
					"as-child": "",
					"force-mount": ""
				}, {
					default: j(() => [M(s("div", {
						id: w(n),
						class: "ui-section__content"
					}, [b(r.$slots, "default", {}, void 0, !0)], 8, Hn), [[k, t.value]])]),
					_: 3
				})) : b(r.$slots, "default", {}, void 0, !0, 2)
			]),
			_: 3
		}, 8, ["data-appearance", "open"]));
	}
}), [["__scopeId", "data-v-8d0608c2"]]), Wn = {
	class: "ui-form-row",
	"data-ui": "form-row"
}, Gn = { class: "ui-form-row__body" }, Kn = ["for"], qn = ["id"], Jn = { class: "ui-form-row__control" }, Yn = /*#__PURE__*/ K(/* @__PURE__ */ u({
	__name: "UiFormRow",
	props: {
		label: {},
		description: {},
		icon: {},
		id: {}
	},
	setup(e) {
		let t = e, n = T();
		return (r, l) => (_(), o("div", Wn, [s("div", Gn, [s("label", { for: t.id ?? w(n) }, [e.icon ? (_(), i(x(e.icon), {
			key: 0,
			size: 18,
			"aria-hidden": "true"
		})) : a("v-if", !0), c(C(e.label), 1)], 8, Kn), e.description ? (_(), o("p", {
			key: 0,
			id: `${t.id ?? w(n)}-description`
		}, C(e.description), 9, qn)) : a("v-if", !0)]), s("div", Jn, [b(r.$slots, "default", {
			id: t.id ?? w(n),
			describedby: e.description ? `${t.id ?? w(n)}-description` : void 0
		}, void 0, !0)])]));
	}
}), [["__scopeId", "data-v-09c39235"]]), Xn = {}, Zn = {
	class: "ui-toolbar",
	"data-ui": "toolbar"
}, Qn = { class: "ui-toolbar__content" }, $n = {
	key: 0,
	class: "ui-toolbar__actions"
};
function er(e, t) {
	return _(), o("div", Zn, [s("div", Qn, [b(e.$slots, "default", {}, void 0, !0)]), e.$slots.actions ? (_(), o("div", $n, [b(e.$slots, "actions", {}, void 0, !0)])) : a("v-if", !0)]);
}
var tr = /*#__PURE__*/ K(Xn, [["render", er], ["__scopeId", "data-v-fe93da01"]]), nr = ["value", "aria-label"], rr = /*#__PURE__*/ K(/* @__PURE__ */ u({
	__name: "UiProgress",
	props: {
		label: {},
		value: {}
	},
	setup(e) {
		return (t, n) => (_(), o("progress", {
			class: "ui-progress",
			"data-ui": "progress",
			value: e.value,
			max: "100",
			"aria-label": e.label
		}, null, 8, nr));
	}
}), [["__scopeId", "data-v-13af356b"]]), ir = ["data-state", "data-density"], ar = { class: "ui-progress-row__heading" }, or = ["title"], sr = ["aria-label"], cr = /*#__PURE__*/ K(/* @__PURE__ */ u({
	__name: "UiProgressRow",
	props: {
		density: { default: "default" },
		showProgress: {
			type: Boolean,
			default: !0
		},
		statusDisplay: { default: "percent" },
		label: {},
		state: {},
		statusLabel: {},
		value: {}
	},
	setup(e) {
		let n = e, l = {
			pending: qe,
			running: Qe,
			succeeded: Ye,
			failed: Xe
		}, u = r(() => n.state === "succeeded" ? 100 : n.value === void 0 ? void 0 : Math.min(100, Math.max(0, n.value)));
		return (n, r) => (_(), o("div", {
			class: "ui-progress-row",
			"data-ui": "progress-row",
			"data-state": e.state,
			"data-density": e.density
		}, [
			s("div", ar, [
				(_(), i(x(l[e.state]), {
					size: e.density === "compact" ? 15 : 18,
					class: "ui-progress-row__icon",
					"aria-hidden": "true"
				}, null, 8, ["size"])),
				s("span", {
					class: "ui-progress-row__label",
					title: e.label
				}, C(e.label), 9, or),
				s("span", {
					class: "ui-progress-row__status",
					"aria-label": e.statusLabel
				}, [e.statusDisplay === "percent" && u.value !== void 0 ? (_(), o(t, { key: 0 }, [c(C(u.value) + "%", 1)], 64)) : (_(), o(t, { key: 1 }, [c(C(e.statusLabel), 1)], 64))], 8, sr)
			]),
			e.showProgress ? (_(), i(rr, {
				key: 0,
				label: e.label,
				value: u.value
			}, null, 8, ["label", "value"])) : a("v-if", !0),
			b(n.$slots, "default", {}, void 0, !0)
		], 8, ir));
	}
}), [["__scopeId", "data-v-840f5068"]]), lr = e.enum([
	"UI_THEME_DUPLICATE",
	"UI_THEME_INVALID_TOKEN",
	"UI_THEME_NOT_INSTALLED",
	"UI_THEME_UNAVAILABLE"
]), ur = lr.enum;
export { Zt as UiActionCard, on as UiBadge, q as UiButton, Cn as UiCard, Qt as UiContextMenu, Gt as UiDialog, wn as UiDropdownMenu, dn as UiEmptyState, ur as UiErrorCode, lr as UiErrorCodeSchema, dt as UiField, Yn as UiFormRow, gt as UiInput, On as UiList, In as UiListItem, rr as UiProgress, cr as UiProgressRow, zt as UiResizeHandle, Q as UiScrollArea, Un as UiSection, bt as UiSelect, en as UiSlider, $t as UiSwitch, nn as UiTabs, Ot as UiToastStack, tr as UiToolbar, Y as UiTransition, Mt as uiResizeEdges, Jt as vSelectableAction };
