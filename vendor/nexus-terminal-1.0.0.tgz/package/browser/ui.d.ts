import * as vue from 'vue';
import { Component, InputTypeHTMLAttribute, VNodeChild, ObjectDirective, MaybeRefOrGetter } from 'vue';
import { z } from 'zod';

type UiButtonAppearance = 'solid' | 'soft' | 'ghost' | 'glass';
/** Display-only data. Callers translate messages reactively and own retention. */
interface UiToastItem {
    readonly id: string | number;
    readonly message: string;
    readonly tone: 'info' | 'success' | 'warning' | 'error';
}
interface UiToastStackProps {
    items: readonly UiToastItem[];
    label: string;
    closeLabel: string;
    expandLabel: string;
    collapseLabel: string;
    /** Accessible position text, translated by the caller. Position 1 is newest. */
    positionLabel: (position: number, total: number) => string;
    duration?: number;
}
type UiButtonTone = 'neutral' | 'primary' | 'success' | 'warning' | 'danger';
/** Shared sizing vocabulary for input, select and button controls. */
type UiControlDensity = 'compact' | 'default' | 'comfortable' | 'touch';
type UiButtonDensity = UiControlDensity;
type UiButtonLoadingAnimation = 'icon' | 'spinner';
interface UiButtonProps {
    appearance?: UiButtonAppearance;
    tone?: UiButtonTone;
    density?: UiButtonDensity;
    type?: 'button' | 'submit' | 'reset';
    disabled?: boolean;
    /** 加载时保留原内容占位及无障碍名称，禁止重复提交，不改变按钮尺寸。 */
    loading?: boolean;
    /**
     * icon 旋转 leading 原图标，iconOnly 则旋转原内容；无图标时回退 spinner。
     * spinner 在 leading 原位置显示圆圈并保留文字；纯图标或无 leading 时居中显示圆圈。
     */
    loadingAnimation?: UiButtonLoadingAnimation;
    block?: boolean;
    /** 纯图标按钮须由调用方提供 aria-label 或 aria-labelledby。 */
    iconOnly?: boolean;
}
interface UiSelectOption {
    value: string;
    label: string;
    disabled?: boolean;
}
type UiSelectDensity = UiControlDensity;
interface UiSelectProps {
    /** 文案由调用方按当前语言提供；value 使用稳定业务标识。 */
    options: readonly UiSelectOption[];
    placeholder?: string;
    name?: string;
    required?: boolean;
    disabled?: boolean;
    invalid?: boolean;
    block?: boolean;
    density?: UiSelectDensity;
    /** 弹层比选择框宽时默认向两侧等量展开；start / end 按阅读方向与边缘对齐。 */
    contentAlign?: 'start' | 'center' | 'end';
}
type UiDialogSize = 'sm' | 'md' | 'lg' | 'xl' | 'fullscreen';
/** 右下角隐藏缩放区域；只提供命中与键盘增量，不管理容器的尺寸及持久化。 */
interface UiResizeHandleProps {
    /** 调用方提供本地化的可访问名称。 */
    label: string;
    /** 提供连续的外沿四边及角落命中区；容器须允许溢出，并单独裁剪内容。 */
    edges?: boolean;
}
interface UiDialogProps {
    /** Nonmodal panels share host overlay state without blocking their application. */
    modal?: boolean;
    /** 必须提供可访问名称，不从业务内容猜测标题。 */
    title: string;
    description?: string;
    /** 调用方提供本地化的关闭按钮名称。 */
    closeLabel: string;
    size?: UiDialogSize;
    showClose?: boolean;
    /** 暂时禁止用户关闭，保留关闭按钮的位置；宿主仍可主动更新 open。 */
    closeDisabled?: boolean;
    closeOnEscape?: boolean;
    closeOnInteractOutside?: boolean;
    /** 标题区域拖动；正文输入、按钮和滚动手势不参与拖动。全屏时禁用。 */
    draggable?: boolean;
    /** 默认启用边缘/角落缩放，可显式关闭；正文独立滚动。全屏时禁用。 */
    resizable?: boolean;
    /** 缩放手柄的本地化名称；手柄聚焦后也支持方向键调整大小。 */
    resizeLabel?: string;
    /** 稳定的业务标识。仅在当前浏览器按公共布局分档记忆位置、大小，不写入后端。 */
    persistenceKey?: string;
    /** Apply the same gutter to the fixed header/footer and scrolling body. */
    gutter?: UiScrollAreaProps['gutter'];
    /** 正文滚动条的可见性；隐藏时仍保留原生滚动。 */
    scrollbar?: UiScrollAreaProps['scrollbar'];
}
interface UiActionCardProps {
    label: string;
    disabled?: boolean;
}
interface UiMenuItem {
    id: string;
    label: string;
    icon?: Component;
    disabled?: boolean;
    tone?: 'neutral' | 'danger';
    /** Visually separate the following action group without creating a selectable row. */
    separatorBefore?: boolean;
}
interface UiContextMenuProps {
    items: readonly UiMenuItem[];
    disabled?: boolean;
}
/** 原生输入属性和事件透传给 input；插槽只负责图标或附加按钮。 */
interface UiInputProps {
    type?: InputTypeHTMLAttribute;
    disabled?: boolean;
    density?: UiControlDensity;
    invalid?: boolean;
}
interface UiFieldProps {
    label: string;
    hint?: string;
    id?: string;
}
interface UiSwitchProps {
    disabled?: boolean;
    name?: string;
    required?: boolean;
}
/** 单值滑条；update 用于预览，commit 用于确认，cancel 用于撤销预览。 */
interface UiSliderProps {
    modelValue: number;
    min?: number;
    max?: number;
    step?: number;
    disabled?: boolean;
    name?: string;
}
interface UiTab {
    value: string;
    label: string;
    disabled?: boolean;
    icon?: Component;
}
interface UiTabsProps {
    options: readonly UiTab[];
    label: string;
    defaultValue?: string;
    /** 共同占位避免切换跳高；隐藏页不参与焦点和交互。 */ stableHeight?: boolean;
}
/** 展示语义由调用方决定；组件不订阅或推导业务状态。 */
interface UiBadgeProps {
    tone?: UiButtonTone;
    dot?: boolean;
}
/** 文案及图标由调用方提供，内部不绑定业务或语言。 */
interface UiEmptyStateProps {
    title: string;
    description?: string;
    icon?: Component;
}
/** 通用条目卡片：主区域可点击；标签、右上标记和右下操作由插槽提供，不推导业务状态。 */
interface UiCardProps {
    title: string;
    /** 主操作的无障碍名称；省略时由卡片内容生成。 */
    actionLabel?: string;
    description?: string;
    icon?: Component;
    tone?: UiButtonTone;
    disabled?: boolean;
}
/** 点击触发的动作菜单，与选择框和右键菜单互斥；业务只接收稳定的选项 ID。 */
interface UiDropdownMenuProps {
    items: readonly UiMenuItem[];
    disabled?: boolean;
    align?: 'start' | 'center' | 'end';
}
/** 通用静态列表项，业务操作放在 actions 插槽，不将整行伪装成按钮。 */
interface UiListItemProps {
    title: string;
    description?: string;
    icon?: Component;
}
/** 原生滚动条容器；不模拟滚动，也不添加业务布局或文案。 */
interface UiScrollAreaProps {
    /** 将样式和属性交给唯一子元素，保留现有 DOM、语义与事件，不增加包装层。 */
    asChild?: boolean;
    /** auto 按需占位；stable 固定单侧占位；symmetric 对称占位，适合居中弹窗。 */
    gutter?: 'auto' | 'stable' | 'symmetric';
    /** hidden 用于与滚动正文对齐的固定标题和页脚，共用同一 gutter 规则。 */
    overflow?: 'auto' | 'hidden';
    /** hidden 只隐藏滚动条，不禁用鼠标、触摸或键盘滚动，也不保留滚动条占位。 */
    scrollbar?: 'auto' | 'hidden';
}
/** Pure layout: business state and translated content belong to the caller. */
interface UiSectionProps {
    title?: string;
    description?: string;
    icon?: Component;
    appearance?: 'plain' | 'panel';
    /** 提供带展开状态的标题栏按钮；内容保持挂载，默认展开，可通过 v-model:open 控制。 */
    collapsible?: boolean;
}
interface UiFormRowProps {
    label: string;
    description?: string;
    icon?: Component;
    id?: string;
}
interface UiProgressProps {
    label: string;
    /** Omit for indeterminate work; explicit zero remains determinate. */
    value?: number;
}
type UiProgressState = 'pending' | 'running' | 'succeeded' | 'failed';
interface UiProgressRowProps {
    density?: 'default' | 'compact';
    /** 默认显示横向进度条；关闭时保留状态图标、名称及百分比。 */
    showProgress?: boolean;
    /** percent 显示可计量进度；label 用状态文字表示不可计量的工作，不推算百分比。 */
    statusDisplay?: 'percent' | 'label';
    label: string;
    state: UiProgressState;
    statusLabel: string;
    value?: number;
}
/** Shared transform/opacity presence transition, using host motion preferences. */
interface UiTransitionProps {
    preset?: 'fade' | 'panel';
    appear?: boolean;
}

type __VLS_Slots$i = {
    default?: () => VNodeChild;
    leading?: () => VNodeChild;
    trailing?: () => VNodeChild;
};
declare const __VLS_base$i: vue.DefineComponent<UiButtonProps, {}, {}, {}, {}, vue.ComponentOptionsMixin, vue.ComponentOptionsMixin, {}, string, vue.PublicProps, Readonly<UiButtonProps> & Readonly<{}>, {
    type: "button" | "submit" | "reset";
    appearance: UiButtonAppearance;
    tone: UiButtonTone;
    density: UiControlDensity;
    disabled: boolean;
    loading: boolean;
    loadingAnimation: UiButtonLoadingAnimation;
    block: boolean;
    iconOnly: boolean;
}, {}, {}, {}, string, vue.ComponentProvideOptions, false, {}, any>;
declare const __VLS_export$o: __VLS_WithSlots$i<typeof __VLS_base$i, __VLS_Slots$i>;
declare const _default$o: typeof __VLS_export$o;

type __VLS_WithSlots$i<T, S> = T & {
    new (): {
        $slots: S;
    };
};

declare const __VLS_template$e: () => {
    __VLS_Slots: {
        default?: (props: {
            id: string;
            describedby: string | undefined;
        }) => any;
    };
};
type __VLS_Slots$h = ReturnType<typeof __VLS_template$e>['__VLS_Slots'];
declare const __VLS_base$h: vue.DefineComponent<UiFieldProps, {}, {}, {}, {}, vue.ComponentOptionsMixin, vue.ComponentOptionsMixin, {}, string, vue.PublicProps, Readonly<UiFieldProps> & Readonly<{}>, {}, {}, {}, {}, string, vue.ComponentProvideOptions, false, {}, any>;
declare const __VLS_export$n: __VLS_WithSlots$h<typeof __VLS_base$h, __VLS_Slots$h>;
declare const _default$n: typeof __VLS_export$n;

type __VLS_WithSlots$h<T, S> = T & {
    new (): {
        $slots: S;
    };
};

type __VLS_Props$7 = UiInputProps;
type __VLS_ModelProps$7 = {
    modelValue?: string;
};
type __VLS_PublicProps$7 = __VLS_Props$7 & __VLS_ModelProps$7;
declare const __VLS_template$d: () => {
    __VLS_Slots: {
        leading?: (props: {}) => any;
    } & {
        trailing?: (props: {}) => any;
    };
};
type __VLS_Slots$g = ReturnType<typeof __VLS_template$d>['__VLS_Slots'];
declare const __VLS_base$g: vue.DefineComponent<__VLS_PublicProps$7, {}, {}, {}, {}, vue.ComponentOptionsMixin, vue.ComponentOptionsMixin, {
    "update:modelValue": (value: string) => any;
}, string, vue.PublicProps, Readonly<__VLS_PublicProps$7> & Readonly<{
    "onUpdate:modelValue"?: ((value: string) => any) | undefined;
}>, {
    type: vue.InputTypeHTMLAttribute;
    density: UiControlDensity;
}, {}, {}, {}, string, vue.ComponentProvideOptions, false, {}, any>;
declare const __VLS_export$m: __VLS_WithSlots$g<typeof __VLS_base$g, __VLS_Slots$g>;
declare const _default$m: typeof __VLS_export$m;

type __VLS_WithSlots$g<T, S> = T & {
    new (): {
        $slots: S;
    };
};

type __VLS_Props$6 = UiSelectProps;
type __VLS_ModelProps$6 = {
    modelValue?: string;
    'open'?: boolean;
};
type __VLS_PublicProps$6 = __VLS_Props$6 & __VLS_ModelProps$6;
declare const __VLS_export$l: vue.DefineComponent<__VLS_PublicProps$6, {}, {}, {}, {}, vue.ComponentOptionsMixin, vue.ComponentOptionsMixin, {
    "update:modelValue": (value: string | undefined) => any;
    "update:open": (value: boolean) => any;
}, string, vue.PublicProps, Readonly<__VLS_PublicProps$6> & Readonly<{
    "onUpdate:modelValue"?: ((value: string | undefined) => any) | undefined;
    "onUpdate:open"?: ((value: boolean) => any) | undefined;
}>, {
    density: UiControlDensity;
    disabled: boolean;
    block: boolean;
    invalid: boolean;
    required: boolean;
    contentAlign: "start" | "center" | "end";
}, {}, {}, {}, string, vue.ComponentProvideOptions, false, {}, any>;
declare const _default$l: typeof __VLS_export$l;

declare const __VLS_export$k: vue.DefineComponent<UiToastStackProps, {}, {}, {}, {}, vue.ComponentOptionsMixin, vue.ComponentOptionsMixin, {
    dismiss: (id: string | number) => any;
}, string, vue.PublicProps, Readonly<UiToastStackProps> & Readonly<{
    onDismiss?: ((id: string | number) => any) | undefined;
}>, {
    duration: number;
}, {}, {}, {}, string, vue.ComponentProvideOptions, false, {}, any>;
declare const _default$k: typeof __VLS_export$k;

type __VLS_Props$5 = UiDialogProps;
type __VLS_Slots$f = {
    title?: (props: {
        title: string;
    }) => VNodeChild;
    body?: (props: {
        close: () => void;
    }) => VNodeChild;
    default?: (props: {
        close: () => void;
    }) => VNodeChild;
    footer?: (props: {
        close: () => void;
    }) => VNodeChild;
};
type __VLS_ModelProps$5 = {
    'open'?: boolean;
};
type __VLS_PublicProps$5 = __VLS_Props$5 & __VLS_ModelProps$5;
declare const __VLS_base$f: vue.DefineComponent<__VLS_PublicProps$5, {}, {}, {}, {}, vue.ComponentOptionsMixin, vue.ComponentOptionsMixin, {
    "update:open": (value: boolean) => any;
    storageError: (cause: unknown) => any;
}, string, vue.PublicProps, Readonly<__VLS_PublicProps$5> & Readonly<{
    "onUpdate:open"?: ((value: boolean) => any) | undefined;
    onStorageError?: ((cause: unknown) => any) | undefined;
}>, {
    gutter: "auto" | "stable" | "symmetric";
    size: UiDialogSize;
    modal: boolean;
    showClose: boolean;
    closeDisabled: boolean;
    closeOnEscape: boolean;
    closeOnInteractOutside: boolean;
    resizable: boolean;
}, {}, {}, {}, string, vue.ComponentProvideOptions, false, {}, any>;
declare const __VLS_export$j: __VLS_WithSlots$f<typeof __VLS_base$f, __VLS_Slots$f>;
declare const _default$j: typeof __VLS_export$j;

type __VLS_WithSlots$f<T, S> = T & {
    new (): {
        $slots: S;
    };
};

declare const __VLS_template$c: () => {
    __VLS_Slots: {
        default?: (props: {}) => any;
    };
};
type __VLS_Slots$e = ReturnType<typeof __VLS_template$c>['__VLS_Slots'];
declare const __VLS_base$e: vue.DefineComponent<UiTransitionProps, {}, {}, {}, {}, vue.ComponentOptionsMixin, vue.ComponentOptionsMixin, {}, string, vue.PublicProps, Readonly<UiTransitionProps> & Readonly<{}>, {
    preset: "panel" | "fade";
    appear: boolean;
}, {}, {}, {}, string, vue.ComponentProvideOptions, false, {}, any>;
declare const __VLS_export$i: __VLS_WithSlots$e<typeof __VLS_base$e, __VLS_Slots$e>;
declare const _default$i: typeof __VLS_export$i;

type __VLS_WithSlots$e<T, S> = T & {
    new (): {
        $slots: S;
    };
};

declare const __VLS_export$h: vue.DefineComponent<UiResizeHandleProps, {}, {}, {}, {}, vue.ComponentOptionsMixin, vue.ComponentOptionsMixin, {
    resize: (widthDelta: number, heightDelta: number) => any;
}, string, vue.PublicProps, Readonly<UiResizeHandleProps> & Readonly<{
    onResize?: ((widthDelta: number, heightDelta: number) => any) | undefined;
}>, {}, {}, {}, {}, string, vue.ComponentProvideOptions, false, {}, any>;
declare const _default$h: typeof __VLS_export$h;

/** Interact.js 显式命中区域；不按距离猜测边缘，避免抢占滚动条或正文。 */
declare const uiResizeEdges: {
    readonly top: "[data-ui-resize-edges~=\"top\"]";
    readonly right: "[data-ui-resize-edges~=\"right\"]";
    readonly bottom: "[data-ui-resize-edges~=\"bottom\"]";
    readonly left: "[data-ui-resize-edges~=\"left\"]";
};

/** 富内容操作区域：原生拖选/复制优先于点击；不接管剪贴板、右键或键盘激活。 */
declare const vSelectableAction: ObjectDirective<HTMLElement>;

declare const __VLS_template$b: () => {
    __VLS_Slots: {
        default?: (props: {}) => any;
    };
};
type __VLS_Slots$d = ReturnType<typeof __VLS_template$b>['__VLS_Slots'];
declare const __VLS_base$d: vue.DefineComponent<UiActionCardProps, {}, {}, {}, {}, vue.ComponentOptionsMixin, vue.ComponentOptionsMixin, {}, string, vue.PublicProps, Readonly<UiActionCardProps> & Readonly<{}>, {}, {}, {}, {}, string, vue.ComponentProvideOptions, false, {}, any>;
declare const __VLS_export$g: __VLS_WithSlots$d<typeof __VLS_base$d, __VLS_Slots$d>;
declare const _default$g: typeof __VLS_export$g;

type __VLS_WithSlots$d<T, S> = T & {
    new (): {
        $slots: S;
    };
};

type __VLS_Props$4 = UiContextMenuProps;
type __VLS_Slots$c = {
    default: () => VNodeChild;
};
type __VLS_ModelProps$4 = {
    'open'?: boolean;
};
type __VLS_PublicProps$4 = __VLS_Props$4 & __VLS_ModelProps$4;
declare const __VLS_base$c: vue.DefineComponent<__VLS_PublicProps$4, {}, {}, {}, {}, vue.ComponentOptionsMixin, vue.ComponentOptionsMixin, {
    select: (id: string) => any;
    "update:open": (value: boolean) => any;
}, string, vue.PublicProps, Readonly<__VLS_PublicProps$4> & Readonly<{
    onSelect?: ((id: string) => any) | undefined;
    "onUpdate:open"?: ((value: boolean) => any) | undefined;
}>, {}, {}, {}, {}, string, vue.ComponentProvideOptions, false, {}, any>;
declare const __VLS_export$f: __VLS_WithSlots$c<typeof __VLS_base$c, __VLS_Slots$c>;
declare const _default$f: typeof __VLS_export$f;

type __VLS_WithSlots$c<T, S> = T & {
    new (): {
        $slots: S;
    };
};

type __VLS_Props$3 = UiSwitchProps;
type __VLS_ModelProps$3 = {
    modelValue?: boolean;
};
type __VLS_PublicProps$3 = __VLS_Props$3 & __VLS_ModelProps$3;
declare const __VLS_export$e: vue.DefineComponent<__VLS_PublicProps$3, {}, {}, {}, {}, vue.ComponentOptionsMixin, vue.ComponentOptionsMixin, {
    "update:modelValue": (value: boolean) => any;
}, string, vue.PublicProps, Readonly<__VLS_PublicProps$3> & Readonly<{
    "onUpdate:modelValue"?: ((value: boolean) => any) | undefined;
}>, {}, {}, {}, {}, string, vue.ComponentProvideOptions, false, {}, any>;
declare const _default$e: typeof __VLS_export$e;

declare const __VLS_export$d: vue.DefineComponent<UiSliderProps, {}, {}, {}, {}, vue.ComponentOptionsMixin, vue.ComponentOptionsMixin, {
    "update:modelValue": (value: number) => any;
    cancel: () => any;
    commit: (value: number) => any;
}, string, vue.PublicProps, Readonly<UiSliderProps> & Readonly<{
    "onUpdate:modelValue"?: ((value: number) => any) | undefined;
    onCancel?: (() => any) | undefined;
    onCommit?: ((value: number) => any) | undefined;
}>, {
    min: number;
    max: number;
    step: number;
}, {}, {}, {}, string, vue.ComponentProvideOptions, false, {}, any>;
declare const _default$d: typeof __VLS_export$d;

type __VLS_Props$2 = UiTabsProps;
type __VLS_ModelProps$2 = {
    modelValue?: string;
};
type __VLS_PublicProps$2 = __VLS_Props$2 & __VLS_ModelProps$2;
declare const __VLS_template$a: () => {
    __VLS_Slots: {
        [x: string]: ((props: {}) => any) | undefined;
    };
};
type __VLS_Slots$b = ReturnType<typeof __VLS_template$a>['__VLS_Slots'];
declare const __VLS_base$b: vue.DefineComponent<__VLS_PublicProps$2, {}, {}, {}, {}, vue.ComponentOptionsMixin, vue.ComponentOptionsMixin, {
    "update:modelValue": (value: string | undefined) => any;
}, string, vue.PublicProps, Readonly<__VLS_PublicProps$2> & Readonly<{
    "onUpdate:modelValue"?: ((value: string | undefined) => any) | undefined;
}>, {}, {}, {}, {}, string, vue.ComponentProvideOptions, false, {}, any>;
declare const __VLS_export$c: __VLS_WithSlots$b<typeof __VLS_base$b, __VLS_Slots$b>;
declare const _default$c: typeof __VLS_export$c;

type __VLS_WithSlots$b<T, S> = T & {
    new (): {
        $slots: S;
    };
};

declare const __VLS_template$9: () => {
    __VLS_Slots: {
        default?: (props: {}) => any;
    };
};
type __VLS_Slots$a = ReturnType<typeof __VLS_template$9>['__VLS_Slots'];
declare const __VLS_base$a: vue.DefineComponent<UiBadgeProps, {}, {}, {}, {}, vue.ComponentOptionsMixin, vue.ComponentOptionsMixin, {}, string, vue.PublicProps, Readonly<UiBadgeProps> & Readonly<{}>, {
    tone: UiButtonTone;
    dot: boolean;
}, {}, {}, {}, string, vue.ComponentProvideOptions, false, {}, any>;
declare const __VLS_export$b: __VLS_WithSlots$a<typeof __VLS_base$a, __VLS_Slots$a>;
declare const _default$b: typeof __VLS_export$b;

type __VLS_WithSlots$a<T, S> = T & {
    new (): {
        $slots: S;
    };
};

declare const __VLS_template$8: () => {
    __VLS_Slots: {
        icon?: (props: {}) => any;
    } & {
        default?: (props: {}) => any;
    };
};
type __VLS_Slots$9 = ReturnType<typeof __VLS_template$8>['__VLS_Slots'];
declare const __VLS_base$9: vue.DefineComponent<UiEmptyStateProps, {}, {}, {}, {}, vue.ComponentOptionsMixin, vue.ComponentOptionsMixin, {}, string, vue.PublicProps, Readonly<UiEmptyStateProps> & Readonly<{}>, {}, {}, {}, {}, string, vue.ComponentProvideOptions, false, {}, any>;
declare const __VLS_export$a: __VLS_WithSlots$9<typeof __VLS_base$9, __VLS_Slots$9>;
declare const _default$a: typeof __VLS_export$a;

type __VLS_WithSlots$9<T, S> = T & {
    new (): {
        $slots: S;
    };
};

declare const __VLS_template$7: () => {
    __VLS_Slots: {
        icon?: (props: {}) => any;
    } & {
        tags?: (props: {}) => any;
    } & {
        aside?: (props: {}) => any;
    } & {
        badge?: (props: {}) => any;
    } & {
        actions?: (props: {}) => any;
    } & {
        footer?: (props: {}) => any;
    };
};
type __VLS_Slots$8 = ReturnType<typeof __VLS_template$7>['__VLS_Slots'];
declare const __VLS_base$8: vue.DefineComponent<UiCardProps, {}, {}, {}, {}, vue.ComponentOptionsMixin, vue.ComponentOptionsMixin, {
    select: () => any;
}, string, vue.PublicProps, Readonly<UiCardProps> & Readonly<{
    onSelect?: (() => any) | undefined;
}>, {
    tone: UiButtonTone;
}, {}, {}, {}, string, vue.ComponentProvideOptions, false, {}, any>;
declare const __VLS_export$9: __VLS_WithSlots$8<typeof __VLS_base$8, __VLS_Slots$8>;
declare const _default$9: typeof __VLS_export$9;

type __VLS_WithSlots$8<T, S> = T & {
    new (): {
        $slots: S;
    };
};

type __VLS_Props$1 = UiDropdownMenuProps;
type __VLS_Slots$7 = {
    default: () => VNodeChild;
};
type __VLS_ModelProps$1 = {
    'open'?: boolean;
};
type __VLS_PublicProps$1 = __VLS_Props$1 & __VLS_ModelProps$1;
declare const __VLS_base$7: vue.DefineComponent<__VLS_PublicProps$1, {}, {}, {}, {}, vue.ComponentOptionsMixin, vue.ComponentOptionsMixin, {
    select: (id: string) => any;
    "update:open": (value: boolean) => any;
}, string, vue.PublicProps, Readonly<__VLS_PublicProps$1> & Readonly<{
    onSelect?: ((id: string) => any) | undefined;
    "onUpdate:open"?: ((value: boolean) => any) | undefined;
}>, {
    align: "start" | "center" | "end";
}, {}, {}, {}, string, vue.ComponentProvideOptions, false, {}, any>;
declare const __VLS_export$8: __VLS_WithSlots$7<typeof __VLS_base$7, __VLS_Slots$7>;
declare const _default$8: typeof __VLS_export$8;

type __VLS_WithSlots$7<T, S> = T & {
    new (): {
        $slots: S;
    };
};

declare const __VLS_template$6: () => {
    __VLS_Slots: {
        default?: (props: {}) => any;
    };
};
type __VLS_Slots$6 = ReturnType<typeof __VLS_template$6>['__VLS_Slots'];
declare const __VLS_base$6: vue.DefineComponent<{}, {}, {}, {}, {}, vue.ComponentOptionsMixin, vue.ComponentOptionsMixin, {}, string, vue.PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, vue.ComponentProvideOptions, true, {}, any>;
declare const __VLS_export$7: __VLS_WithSlots$6<typeof __VLS_base$6, __VLS_Slots$6>;
declare const _default$7: typeof __VLS_export$7;

type __VLS_WithSlots$6<T, S> = T & {
    new (): {
        $slots: S;
    };
};

declare const __VLS_template$5: () => {
    __VLS_Slots: {
        icon?: (props: {}) => any;
    } & {
        badge?: (props: {}) => any;
    } & {
        description?: (props: {}) => any;
    } & {
        actions?: (props: {}) => any;
    };
};
type __VLS_Slots$5 = ReturnType<typeof __VLS_template$5>['__VLS_Slots'];
declare const __VLS_base$5: vue.DefineComponent<UiListItemProps, {}, {}, {}, {}, vue.ComponentOptionsMixin, vue.ComponentOptionsMixin, {}, string, vue.PublicProps, Readonly<UiListItemProps> & Readonly<{}>, {}, {}, {}, {}, string, vue.ComponentProvideOptions, false, {}, any>;
declare const __VLS_export$6: __VLS_WithSlots$5<typeof __VLS_base$5, __VLS_Slots$5>;
declare const _default$6: typeof __VLS_export$6;

type __VLS_WithSlots$5<T, S> = T & {
    new (): {
        $slots: S;
    };
};

declare const __VLS_template$4: () => {
    __VLS_Slots: {
        default?: (props: {}) => any;
    };
};
type __VLS_Slots$4 = ReturnType<typeof __VLS_template$4>['__VLS_Slots'];
declare const __VLS_base$4: vue.DefineComponent<UiScrollAreaProps, {}, {}, {}, {}, vue.ComponentOptionsMixin, vue.ComponentOptionsMixin, {}, string, vue.PublicProps, Readonly<UiScrollAreaProps> & Readonly<{}>, {
    gutter: "auto" | "stable" | "symmetric";
    scrollbar: "auto" | "hidden";
    overflow: "auto" | "hidden";
    asChild: boolean;
}, {}, {}, {}, string, vue.ComponentProvideOptions, false, {}, any>;
declare const __VLS_export$5: __VLS_WithSlots$4<typeof __VLS_base$4, __VLS_Slots$4>;
declare const _default$5: typeof __VLS_export$5;

type __VLS_WithSlots$4<T, S> = T & {
    new (): {
        $slots: S;
    };
};

type __VLS_Props = UiSectionProps;
type __VLS_ModelProps = {
    'open'?: boolean;
};
type __VLS_PublicProps = __VLS_Props & __VLS_ModelProps;
declare const __VLS_template$3: () => {
    __VLS_Slots: {
        actions?: (props: {}) => any;
    } & {
        default?: (props: {}) => any;
    } & {
        default?: (props: {}) => any;
    };
};
type __VLS_Slots$3 = ReturnType<typeof __VLS_template$3>['__VLS_Slots'];
declare const __VLS_base$3: vue.DefineComponent<__VLS_PublicProps, {}, {}, {}, {}, vue.ComponentOptionsMixin, vue.ComponentOptionsMixin, {
    "update:open": (value: boolean) => any;
}, string, vue.PublicProps, Readonly<__VLS_PublicProps> & Readonly<{
    "onUpdate:open"?: ((value: boolean) => any) | undefined;
}>, {
    appearance: "plain" | "panel";
    collapsible: boolean;
}, {}, {}, {}, string, vue.ComponentProvideOptions, false, {}, any>;
declare const __VLS_export$4: __VLS_WithSlots$3<typeof __VLS_base$3, __VLS_Slots$3>;
declare const _default$4: typeof __VLS_export$4;

type __VLS_WithSlots$3<T, S> = T & {
    new (): {
        $slots: S;
    };
};

declare const __VLS_template$2: () => {
    __VLS_Slots: {
        default?: (props: {
            id: string;
            describedby: string | undefined;
        }) => any;
    };
};
type __VLS_Slots$2 = ReturnType<typeof __VLS_template$2>['__VLS_Slots'];
declare const __VLS_base$2: vue.DefineComponent<UiFormRowProps, {}, {}, {}, {}, vue.ComponentOptionsMixin, vue.ComponentOptionsMixin, {}, string, vue.PublicProps, Readonly<UiFormRowProps> & Readonly<{}>, {}, {}, {}, {}, string, vue.ComponentProvideOptions, false, {}, any>;
declare const __VLS_export$3: __VLS_WithSlots$2<typeof __VLS_base$2, __VLS_Slots$2>;
declare const _default$3: typeof __VLS_export$3;

type __VLS_WithSlots$2<T, S> = T & {
    new (): {
        $slots: S;
    };
};

declare const __VLS_template$1: () => {
    __VLS_Slots: {
        default?: (props: {}) => any;
    } & {
        actions?: (props: {}) => any;
    };
};
type __VLS_Slots$1 = ReturnType<typeof __VLS_template$1>['__VLS_Slots'];
declare const __VLS_base$1: vue.DefineComponent<{}, {}, {}, {}, {}, vue.ComponentOptionsMixin, vue.ComponentOptionsMixin, {}, string, vue.PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, vue.ComponentProvideOptions, true, {}, any>;
declare const __VLS_export$2: __VLS_WithSlots$1<typeof __VLS_base$1, __VLS_Slots$1>;
declare const _default$2: typeof __VLS_export$2;

type __VLS_WithSlots$1<T, S> = T & {
    new (): {
        $slots: S;
    };
};

declare const __VLS_export$1: vue.DefineComponent<UiProgressProps, {}, {}, {}, {}, vue.ComponentOptionsMixin, vue.ComponentOptionsMixin, {}, string, vue.PublicProps, Readonly<UiProgressProps> & Readonly<{}>, {}, {}, {}, {}, string, vue.ComponentProvideOptions, false, {}, any>;
declare const _default$1: typeof __VLS_export$1;

declare const __VLS_template: () => {
    __VLS_Slots: {
        default?: (props: {}) => any;
    };
};
type __VLS_Slots = ReturnType<typeof __VLS_template>['__VLS_Slots'];
declare const __VLS_base: vue.DefineComponent<UiProgressRowProps, {}, {}, {}, {}, vue.ComponentOptionsMixin, vue.ComponentOptionsMixin, {}, string, vue.PublicProps, Readonly<UiProgressRowProps> & Readonly<{}>, {
    density: "default" | "compact";
    showProgress: boolean;
    statusDisplay: "percent" | "label";
}, {}, {}, {}, string, vue.ComponentProvideOptions, false, {}, any>;
declare const __VLS_export: __VLS_WithSlots<typeof __VLS_base, __VLS_Slots>;
declare const _default: typeof __VLS_export;

type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};

type UiThemeMode = 'light' | 'dark';
/**
 * 开放的主题变量覆盖表；空对象合法，不要求主题重复提供所有内置默认值。
 * 内置 UI 使用的 --ui-* 变量默认允许主题覆盖，新增变量不需要修改本类型或登记清单。
 * 通用变量使用 --ui-primary 等语义名称；组件变量使用 --ui-button-background 等组件前缀。
 * 值为单个 CSS 自定义属性的值，例如颜色、阴影、字体或 var(...)，不传选择器和整段样式表。
 * 未覆盖的变量沿用相同 mode 的内置默认值；组件变量可通过 var(...) 引用通用变量。
 * 主题只覆盖外观，不替换组件结构、交互或业务逻辑，也不公开内部 DOM 和 CSS 类名。
 */
type UiThemeTokens = Readonly<Record<`--ui-${string}`, string>>;
interface UiTheme {
    /** 当前注册表内唯一标识；命名空间及提供方身份由上层装配，不在基础 UI 中推断。 */
    readonly id: string;
    /** 随本体语言响应式变化，不由主题维护第二套语言设置。 */
    readonly label: MaybeRefOrGetter<string>;
    /** 决定未覆盖变量使用哪套内置默认值。 */
    readonly mode: UiThemeMode;
    /** 仅提供本主题需要改变的变量；内置组件 CSS 由 UI 自身统一维护和导出。 */
    readonly tokens: UiThemeTokens;
}

/** Module-owned stable codes. Upstream errors retain their original code in ErrorDetail. */
declare const UiErrorCodeSchema: z.ZodEnum<{
    UI_THEME_DUPLICATE: "UI_THEME_DUPLICATE";
    UI_THEME_INVALID_TOKEN: "UI_THEME_INVALID_TOKEN";
    UI_THEME_NOT_INSTALLED: "UI_THEME_NOT_INSTALLED";
    UI_THEME_UNAVAILABLE: "UI_THEME_UNAVAILABLE";
}>;
type UiErrorCode = z.infer<typeof UiErrorCodeSchema>;
declare const UiErrorCode: {
    UI_THEME_DUPLICATE: "UI_THEME_DUPLICATE";
    UI_THEME_INVALID_TOKEN: "UI_THEME_INVALID_TOKEN";
    UI_THEME_NOT_INSTALLED: "UI_THEME_NOT_INSTALLED";
    UI_THEME_UNAVAILABLE: "UI_THEME_UNAVAILABLE";
};

export { _default$g as UiActionCard, _default$b as UiBadge, _default$o as UiButton, _default$9 as UiCard, _default$f as UiContextMenu, _default$j as UiDialog, _default$8 as UiDropdownMenu, _default$a as UiEmptyState, UiErrorCode, UiErrorCodeSchema, _default$n as UiField, _default$3 as UiFormRow, _default$m as UiInput, _default$7 as UiList, _default$6 as UiListItem, _default$1 as UiProgress, _default as UiProgressRow, _default$h as UiResizeHandle, _default$5 as UiScrollArea, _default$4 as UiSection, _default$l as UiSelect, _default$d as UiSlider, _default$e as UiSwitch, _default$c as UiTabs, _default$k as UiToastStack, _default$2 as UiToolbar, _default$i as UiTransition, uiResizeEdges, vSelectableAction };
export type { UiActionCardProps, UiBadgeProps, UiButtonAppearance, UiButtonDensity, UiButtonLoadingAnimation, UiButtonProps, UiButtonTone, UiCardProps, UiContextMenuProps, UiControlDensity, UiDialogProps, UiDialogSize, UiDropdownMenuProps, UiEmptyStateProps, UiFieldProps, UiFormRowProps, UiInputProps, UiListItemProps, UiMenuItem, UiProgressProps, UiProgressRowProps, UiProgressState, UiResizeHandleProps, UiScrollAreaProps, UiSectionProps, UiSelectDensity, UiSelectOption, UiSelectProps, UiSliderProps, UiSwitchProps, UiTab, UiTabsProps, UiTheme, UiThemeMode, UiThemeTokens, UiToastItem, UiToastStackProps, UiTransitionProps };
