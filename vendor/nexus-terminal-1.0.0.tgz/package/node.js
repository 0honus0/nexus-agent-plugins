import { n as e, r as t, t as n } from "./log-plugin-api-UW-KBQWD.js";
import { z as r } from "zod";
import "node:crypto";
import "neverthrow";
// src/crypto/node/crypto-plugin-api.ts
var i = r.string().optional(), a = r.discriminatedUnion("mode", [r.strictObject({
	mode: r.literal("local"),
	context: i
}), r.strictObject({
	mode: r.literal("password"),
	password: r.string().min(1).max(1024),
	context: i
})]), o = r.enum([
	"INVALID_INPUT",
	"INVALID_OPTIONS",
	"INVALID_ENVELOPE",
	"AUTHENTICATION_FAILED",
	"UNAVAILABLE",
	"CANCELLED",
	"INTERNAL_ERROR"
]), s = r.strictObject({
	code: o,
	correlationId: r.uuid().optional()
}), c = class extends Error {
	status;
	code;
	constructor(e, t) {
		if (super(t), this.status = e, this.code = t, !Number.isInteger(e) || e < 400 || e > 599 || !/^[A-Z][A-Z0-9_]*$/u.test(t)) throw TypeError("HTTP_FAILURE_INVALID");
	}
};
export { a as CryptoOptionsSchema, c as HttpFailure, n as LogLevelSchema, e as LogParamsSchema, o as PluginCryptoErrorCodeSchema, s as PluginCryptoFailureSchema, t as PluginLogInputSchema };
